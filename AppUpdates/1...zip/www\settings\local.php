<?php
require_once("../.config.inc.php");
header("Location: ".__URL_PATH__."/settings/settings.php?cat=local");
exit();
<?php

$update_data = [
    "flag_style" => [
        "id" => [
            "1" => ['h_align'=>0, 'v_align' => 0],
            "2" => ['h_align'=>0, 'v_align' => 0],
            "3" => ['h_align'=>0, 'v_align' => 0],
            "4" => ['h_align'=>0, 'v_align' => 0],
            "5" => ['h_align'=>0, 'v_align' => 0],
        ],
    ],
];

$new_data = [
    "flag_style" => [
    [
        'style_name' => 'Load Flag',
        'ecol' => 'A',
        'erow' => 27,
        'h_align' => 1,
        'v_align' => 0,
        'bold'=>0,
        'font_size'=>12,
    ],
    ]
];

<?php

$new_column = [
    "form_data_count" => [
        "max_skid" => "TEXT"
    ]
];

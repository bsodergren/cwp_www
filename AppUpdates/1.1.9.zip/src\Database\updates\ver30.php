<?php
/**
 * CWP Media tool
 */

$delete_data = [
    'settings' => [
        'definedName' => ['__SHOW_SOMETHIG__'],
    ],
];

<?php
/**
 * CWP Media tool
 */

namespace CWP\AutoUpdate\Exceptions;

class DownloadException extends \Exception
{
}

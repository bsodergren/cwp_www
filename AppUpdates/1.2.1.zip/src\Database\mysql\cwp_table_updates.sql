DROP TABLE IF EXISTS updates;
CREATE TABLE IF NOT EXISTS `updates` (

  `id` integer  NOT NULL PRIMARY KEY AUTO_INCREMENT,

	`update_filename` TEXT NOT NULL


);

<?php
use CWP\HTML\Footer;

Footer::display();

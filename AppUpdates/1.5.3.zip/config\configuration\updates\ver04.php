<?php
/*
$new_table = ['updates'];

$new_data = [
    "updates" => [
        ["update_filename" => "ver04.php",],
        ["update_filename" => "ver03.php",],
        ["update_filename" => "ver02.php",],
        ["update_filename" => "ver01.php",]
    ]
];
*/
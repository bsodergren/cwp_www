<?php
/**
 * CWP Media tool
 */

namespace CWP\Filesystem;

use League\Flysystem\Filesystem;
use Spatie\Dropbox\Client;
use Spatie\FlysystemDropbox\DropboxAdapter;

class DropBox
{
    public object $adapter;

    public function __construct()
    {



    }
}

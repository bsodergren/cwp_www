<?php
use CWP\HTML\Header;
Header::Display();

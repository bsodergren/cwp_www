<?php

$new_column = [
    "form_data_count" => [
        "form_letter" => "TEXT"
    ]
];

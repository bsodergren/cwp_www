<?php

$new_data = [
    "settings" => [
        [
            "definedName" => '__HALF_FORM_CNT__',
            'setting_value' => '1',
            'setting_type' => 'bool',
            'setting_name' => 'Split Forms',
            'setting_description' => "Automatically split 'ABCD' forms in half",
            'setting_cat'=>'local',
        ],
    ]
];

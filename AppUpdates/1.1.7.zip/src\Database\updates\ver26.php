<?php
$new_data = [
    "settings" => [
        [
            "definedName" => '__SHOW_DECIMAL__',
            'setting_value' => '0',
            'setting_type' => 'bool',
            'setting_name' => "Show Decimal",
            'setting_description' => "decimal places",
            'setting_cat'=>'local',
        ],
    ]
];

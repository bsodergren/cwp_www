<?php
$update_data = [
	"settings" => [
		"definedName" => [
            '__PUB_FACETRIM__'  => [
				"setting_value"=>"",
			],
			'__PDF_NOTRIM__'  => [
				"setting_value"=>"",
			],
			'__NAVBAR_LINKS__'  => [
				"setting_value"=>"{\"Home\":\"\\/index.php\",\"Import\":\"\\/import.php\",\"Settings\":{\"Trim Sizes\":\"\\/settings\\/trim.php\",\"Language\":\"\\/settings\\/language.php\",\"Local Settings\":\"\\/settings\\/local.php\",\"Server Settings\":\"\\/settings\\/settings.php\"}}",
			],
			'__LANG_BINDERY'  => [
				"setting_value"=>"Trim in Bindery",
			],
			'__LANG_MEDIA_LOAD_FLAG'  => [
				"setting_value"=>"Media Load Flag",
			],
			'__LANG_LIFT_SIZE'  => [
				"setting_value"=>"Lift Size",
			],
			'__LANG_TOTAL_COUNT'  => [
				"setting_value"=>"Total Count",
			],
			'__LANG_LIFTS_PER_CARTON'  => [
				"setting_value"=>"Lifts per Carton",
			],
			'__LANG_PCS_PER_CARTON'  => [
				"setting_value"=>"Pcs per Carton",
			],
			'__LANG_FULL_CARTON'  => [
				"setting_value"=>"Full Cartons",
			],
			'__LANG_CNT_LAST_CARTON'  => [
				"setting_value"=>"Count in last Carton",
			],
			'__LANG_TOTAL_CARTONS'  => [
				"setting_value"=>"Total Cartons",
			],
			'__LANG_LAYERS_PER_SKID'  => [
				"setting_value"=>"Layers per Skid",
			],
			'__LANG_NUMBER_OF_FULL_BOXES'  => [
				"setting_value"=>"Full Boxes",
			],
			'__LANG_NUMBER_OF_FULL_LAYERS'  => [
				"setting_value"=>"Full Layers",
			],
			'__LANG_LIFTS_LAST_LAYER'  => [
				"setting_value"=>"Lifts last Layer",
			],
			'__LANG_BINDERY_FACETRIM'  => [
				"setting_value"=>"Facetrim in Bindery",
			],
		],
	],
];
<?php

$new_column = [
    "pub_trim" => [
        "face_trim" => "TEXT"
    ]
];

<?php

$delete_data = [
    "settings" => [
        "definedName" => ['__NAVBAR_LINKS__'],
    ],
];

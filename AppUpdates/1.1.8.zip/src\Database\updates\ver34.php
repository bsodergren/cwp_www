<?php

$update_data = [
    "paper_count" => [
        "id" => [
            "1" => ['max_full'=>135000],
            "2" => ['max_full'=>94500],
            "3" => ['max_full'=>54000],
            "5" => ['max_full'=>94500],
            "6" => ['max_full'=>54000],
            "8" => ['max_full'=>58500],
            "9" => ['max_full'=>42500],
            "11" => ['max_full'=>58500],
            "12" => ['max_full'=>42500],
        ],
    ],
];
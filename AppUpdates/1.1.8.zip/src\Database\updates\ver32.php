<?php

$new_data = [
        "settings" => [
        [
            "definedName" => '__LANG_MAX_SKID',
            'setting_value' => 'Pcs per Skid',
            'setting_type' => 'text',
            'setting_name' => null,
            'setting_description' => null,
            'setting_cat'=>'lang',
        ],
    ]
];
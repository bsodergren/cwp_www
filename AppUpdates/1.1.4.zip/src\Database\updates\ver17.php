<?php

$update_data = [
    "settings" => [

        "definedName" => [
                '__NAVBAR_LINKS__'  => [
                    'setting_value' => '{"Home": "/index.php", "Import": "/import.php", "Trim Sizes": "/settings/trim.php", "Settings": { "Language": "/settings/language.php", "Local Settings": "/settings/local.php", "Server Settings": "/settings/settings.php" }}',
                    'setting_type' => 'array',
                    'setting_name' => 'Navbar Links',
                    'setting_description' => 'Navbar links. Name => file.php',
                    'setting_cat'=>'server',
                ]
            ]
        ]

];

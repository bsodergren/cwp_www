<?php

$update_data = [
    'settings' => [
        'definedName' => [
            '__PUB_FACETRIM__'  => [
                'setting_description'=>'Publications to go to bindery for Face trim',
            ],
            '__PDF_NOTRIM__'  => [
                'setting_description'=>'Publications that dont use any Trimmers',
            ],
        ],
    ],
];

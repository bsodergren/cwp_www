<?php
/**
 * CWP Media tool
 */

$new_data = [
    'settings' => [
        [
            'definedName' => '__DROPBOX_AUTH_TOKEN__',
            'setting_value' => '',
            'setting_type' => 'text',
            'setting_name' => 'Dropbox Token',
            'setting_description' => 'Dropbox Token',
            'setting_cat' => 'local',
        ],
    ],
];

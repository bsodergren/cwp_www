<?php

$new_data = [
    "settings" => [
        [
            "definedName" => '__MEDIA_FILES_DIR__',
            'setting_value' => '',
            'setting_type' => 'text',
            'setting_name' => "Files Directory",
            'setting_description' => "location of all media files",
            'setting_cat'=>'local',
        ],
    ]
];

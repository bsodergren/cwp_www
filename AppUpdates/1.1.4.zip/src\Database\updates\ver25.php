<?php

$update_data = [
    'flag_style' => [
        'style_name' => [
            'Load Flag'  => [
                'width'=>22,
            ],
        ],
    ],
];
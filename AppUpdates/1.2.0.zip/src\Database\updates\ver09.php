<?php

$new_data = [
        "settings" => [
        [
            "definedName" => '__PUB_FACETRIM__',
            'setting_value' => '["FORBES","FORTUNE","ENTREPRENEUR","COSMOPOLITAN"]',
            'setting_type' => 'array',
            'setting_name' => 'Face trim',
            'setting_description' => "Publications not using Facetrimmers",
            'setting_cat'=>'local',
        ],
        [
            "definedName" => '__PDF_NOTRIM__',
            'setting_value' => '["COSMOPOLITAN"]',
            'setting_type' => 'array',
            'setting_name' => 'Skip trimmers',
            'setting_description' => "Publications not using trimmers",
            'setting_cat'=>'local',
        ],
    ]
];

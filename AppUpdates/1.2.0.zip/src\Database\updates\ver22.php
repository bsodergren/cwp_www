<?php

$update_data = [
    'settings' => [
        'definedName' => [
            '__PUB_FACETRIM__'  => [
                'setting_type'=>'list',
            ],
            '__PDF_NOTRIM__'  => [
                'setting_type'=>'list',
            ],
        ],
    ],
];

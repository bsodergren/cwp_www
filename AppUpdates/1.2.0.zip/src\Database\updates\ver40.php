<?php
/**
 * CWP Media tool
 */
$update_data = [
    "flag_style" => [
        "id" => [
            "27" => ['h_align'=>0, 'v_align' => 0],
            "28" => ['h_align'=>0, 'v_align' => 0],
            "29" => ['h_align'=>0, 'v_align' => 0],
            "30" => ['h_align'=>0, 'v_align' => 0],
            "31" => ['h_align'=>0, 'v_align' => 0],
            "32" => ['h_align'=>0, 'v_align' => 0],
            "33" => ['h_align'=>0, 'v_align' => 0],
            "34" => ['h_align'=>0, 'v_align' => 0],
            "35" => ['h_align'=>0, 'v_align' => 0],
        ],
    ],
];
<?php

$new_data = [
    "settings" => [
        [
            "definedName" => '__DROPBOX_FILES_DIR__',
            'setting_value' => '',
            'setting_type' => 'text',
            'setting_name' => "Dropbox Files Directory",
            'setting_description' => "location of all dropbox files",
            'setting_cat'=>'local',
        ],
    ]
];

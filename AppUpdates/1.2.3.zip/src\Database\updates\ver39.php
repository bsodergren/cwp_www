<?php
/**
 * CWP Media tool
 */

 $new_data = [
    "flag_style" => [
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 13,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 14,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 15,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 16,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 17,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 18,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 19,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'C','erow' => 20,'h_align' => 0,'v_align' => 0,'bold'=>0,'font_size'=>14],


        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 13,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 14,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 15,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 16,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 17,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 18,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 19,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
        ['style_name' => 'Load Flag','ecol' => 'D','erow' => 20,'h_align' => 1,'v_align' => 0,'bold'=>1,'font_size'=>14],
    ]
];
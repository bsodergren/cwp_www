<?php

$new_data = [
    "settings" => [
        "definedName" => "__SHOW_DEBUG_PANEL__",
        'setting_name' => 'debug panel',
        'setting_description' => 'User debug panel',
        'setting_type' => 'bool',
        'setting_value' => "0"
    ],
];

<?php 

$new_data = [
        "settings" => [
        [
            "definedName" => '__LANG_BINDERY_FACETRIM',
            'setting_value' => 'Facetrim in Bindery',
            'setting_type' => 'text',
            'setting_name' => null,
            'setting_description' => null,
            'setting_cat'=>'lang',
        ],
    ]
];
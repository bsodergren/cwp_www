<?php
/**
 * CWP Media tool
 */

$change_column = [
    'settings' => [
        [
            'setting_value' => 'BLOB',
        ],
    ],
];

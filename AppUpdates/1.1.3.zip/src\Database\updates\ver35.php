<?php
/**
 * CWP Media tool
 */

$update_data = [
    'settings' => [
        'definedName' => [
            '__HALF_FORM_CNT__'  => [
                'setting_value' => 0,
            ],
        ],
    ],
];

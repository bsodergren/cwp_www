<?php
/**
 * CWP Media tool
 */

$drive_letter = substr($argv[1], 0, 2);
$target_dir = str_replace($drive_letter, '', $argv[1]);
$bin_dir = $target_dir.\DIRECTORY_SEPARATOR.'bin';
$config_ini = $argv[1].\DIRECTORY_SEPARATOR.'public'.\DIRECTORY_SEPARATOR.'config.ini';


$str = <<<EOD
[application]
name=cwp
debug=false
[email]
imap={imap.gmail.com:993/imap/ssl}
username=bjorn.sodergren@gmail.com
password=lhdezcpzgxpuultg
folder=CWP
[db]
type=sqlite
dbname=cwp
host=
username=
password=
[server]
root_dir=$target_dir
bin_dir=$bin_dir
#project_root=\public
web_root=\public\www
url_root=
file_root=\\files\media
EOD;

file_put_contents($config_ini, $str);
echo $str;

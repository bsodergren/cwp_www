<?php



define('__PDF_UPLOAD_DIR__', DIRECTORY_SEPARATOR.'pdf');
define('__ZIP_FILE_DIR__', DIRECTORY_SEPARATOR.'zip');
define('__XLSX_DIRECTORY__', DIRECTORY_SEPARATOR.'xlsx');
define('__EMAIL_PDF_UPLOAD_DIR__', DIRECTORY_SEPARATOR.'uploads');



 define('__LAYOUT_DIR__', DIRECTORY_SEPARATOR.'assets/layout');
 define('__LAYOUT_ROOT__', __HTTP_ROOT__.__LAYOUT_DIR__);
 define('__TEMPLATE_DIR__', __LAYOUT_ROOT__.DIRECTORY_SEPARATOR.'template');

 define('__LAYOUT_HEADER__', __LAYOUT_ROOT__.DIRECTORY_SEPARATOR.'header.php');
 define('__LAYOUT_NAVBAR__', __LAYOUT_ROOT__.DIRECTORY_SEPARATOR.'navbar.php');
 define('__LAYOUT_FOOTER__', __LAYOUT_ROOT__.DIRECTORY_SEPARATOR.'footer.php');


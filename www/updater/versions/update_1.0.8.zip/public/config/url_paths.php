<?php
/**
 * CWP Media tool
 */


define('__URL_HOME__', 'http://'.$_SERVER['HTTP_HOST'].__URL_PATH__);
define('__URL_LAYOUT__', __URL_HOME__.'/assets/layout/');

<?php
$new_table = ['pub_trim'];
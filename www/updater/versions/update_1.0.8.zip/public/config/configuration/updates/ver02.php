<?php


$rename_column = [
    "media_job" => [
        "zip_file" => "zip_exists",
        "xlsx_dir" => "xlsx_exists"
    ]
];

$new_column = [
    "media_job" => [
        "base_dir" => "text"
    ]
];

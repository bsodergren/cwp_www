<?php

class Lang
{

    public static function local($text)
    {

        return $text;

    }

}